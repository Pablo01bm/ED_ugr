var searchData=
[
  ['quitar',['quitar',['../classCola__max.html#a21f1d915c674522d438f8288177e7ecb',1,'Cola_max::quitar()'],['../classCola__max.html#a21f1d915c674522d438f8288177e7ecb',1,'Cola_max::quitar()']]]
];
