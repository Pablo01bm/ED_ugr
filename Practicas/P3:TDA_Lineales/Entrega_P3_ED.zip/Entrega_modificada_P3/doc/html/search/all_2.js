var searchData=
[
  ['frente',['frente',['../classCola__max.html#ad24d6ded47e7696c53dd10e33cce403e',1,'Cola_max::frente()'],['../classCola__max.html#ad24d6ded47e7696c53dd10e33cce403e',1,'Cola_max::frente()']]]
];
