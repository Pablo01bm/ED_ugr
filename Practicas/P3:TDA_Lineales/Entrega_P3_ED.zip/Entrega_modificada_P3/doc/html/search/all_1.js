var searchData=
[
  ['detras',['detras',['../classCola__max.html#a895641f61bc1b4289c32ba847197f83f',1,'Cola_max']]]
];
