var searchData=
[
  ['vacia',['vacia',['../classCola__max.html#af0b18f86af91ef94d7a035f87a4dcb2b',1,'Cola_max::vacia()'],['../classCola__max.html#af0b18f86af91ef94d7a035f87a4dcb2b',1,'Cola_max::vacia()']]]
];
