var searchData=
[
  ['vacia',['vacia',['../classCola__max.html#af0b18f86af91ef94d7a035f87a4dcb2b',1,'Cola_max::vacia()'],['../classCola__max.html#af0b18f86af91ef94d7a035f87a4dcb2b',1,'Cola_max::vacia()']]],
  ['vector_5fdinamico',['Vector_Dinamico',['../classVector__Dinamico.html',1,'']]],
  ['vector_5fdinamico_3c_20pair_3c_20t_2c_20t_20_3e_20_3e',['Vector_Dinamico&lt; pair&lt; T, T &gt; &gt;',['../classVector__Dinamico.html',1,'']]]
];
