var searchData=
[
  ['poner',['poner',['../classCola__max.html#a592785a242bd06ac3530a331fe892ae4',1,'Cola_max::poner(T dato)'],['../classCola__max.html#a592785a242bd06ac3530a331fe892ae4',1,'Cola_max::poner(T dato)']]]
];
