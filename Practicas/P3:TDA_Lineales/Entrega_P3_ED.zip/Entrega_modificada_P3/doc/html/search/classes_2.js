var searchData=
[
  ['vector_5fdinamico',['Vector_Dinamico',['../classVector__Dinamico.html',1,'']]],
  ['vector_5fdinamico_3c_20pair_3c_20t_2c_20t_20_3e_20_3e',['Vector_Dinamico&lt; pair&lt; T, T &gt; &gt;',['../classVector__Dinamico.html',1,'']]]
];
