var searchData=
[
  ['num_5felementos',['num_elementos',['../classCola__max.html#a19ba81d4fee94aeb137247533ba2abc1',1,'Cola_max::num_elementos() const '],['../classCola__max.html#a19ba81d4fee94aeb137247533ba2abc1',1,'Cola_max::num_elementos() const ']]]
];
