Práctica Final REALIZADA POR:

Pablo Borrego Megías y Antonio Quirante Hernández

*******************IMPORTANTE********************

Profesor, le comunicamos que el programa ahora mismo imprime mal la mascara de los aviones y aparece como con rayas blancas de haberse impreso mal, pero debemos decirle que este error ha surgido despues de hacer la documentacion doxygen de las clases, ya que antes de esto, imprimia perfectamente las imagenes de los aviones (con las banderas correspondientes) sin ningun error. Hemos intentado solucionarlo pero no localizamos el problema y es bastante extraño. Un saludo.
