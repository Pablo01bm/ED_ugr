var classPais =
[
    [ "Pais", "classPais.html#a16af2b45eb9d07e7292a58556edc9371", null ],
    [ "GetBandera", "classPais.html#a0ba2a78d564f6ea016e88326b37d6ae3", null ],
    [ "GetPais", "classPais.html#aff8c3008945f2dae8d360c700f796243", null ],
    [ "GetPunto", "classPais.html#ab0f1ede55db35d15670a1c4210fd013d", null ],
    [ "operator<", "classPais.html#a44adc983241faeaa4838ec878db5b314", null ],
    [ "operator==", "classPais.html#a3588e3a03eb40933a5eb576dbac0dfc5", null ],
    [ "operator==", "classPais.html#af55cc0a93e1a807e1291265d2c9b986a", null ],
    [ "operator<<", "classPais.html#a6d1c962b239638bd10f4a58a5aeaa6d5", null ],
    [ "operator>>", "classPais.html#aacd6663db9fb049ff7041c93f4bdbf6a", null ],
    [ "bandera", "classPais.html#a367c39694a5a5d45523298003c5ef009", null ],
    [ "p", "classPais.html#a5e3ea7c2d436a3f80cd6953db7e4995b", null ],
    [ "pais", "classPais.html#ab7f8350a6cb17f1e924f2b9f4616d8a9", null ]
];