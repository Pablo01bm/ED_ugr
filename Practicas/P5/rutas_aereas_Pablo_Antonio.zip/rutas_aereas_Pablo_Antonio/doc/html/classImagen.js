var classImagen =
[
    [ "Imagen", "classImagen.html#ab2e649aa7a105155c7bfdb846abf0528", null ],
    [ "Imagen", "classImagen.html#a4b397c4a3dc0794cab351f96dc9390fd", null ],
    [ "Imagen", "classImagen.html#a5c25efc6e460f6de605942460db48057", null ],
    [ "~Imagen", "classImagen.html#a03dd93c9cf920a9dc0b72f8bd34f2e8a", null ],
    [ "Borrar", "classImagen.html#a8bcdb6302f3d1f9ad74e53eb9fb78eec", null ],
    [ "Copiar", "classImagen.html#a9537dd1e7d6d29b9bf1131cae1619b1b", null ],
    [ "EscribirImagen", "classImagen.html#ae6574af4e39a8647b82e02167a86f30c", null ],
    [ "ExtraeImagen", "classImagen.html#ac654c71422272cbfea703411daa12c8a", null ],
    [ "LeerImagen", "classImagen.html#a3a4b1782bf010d02ded33d1ccd736be4", null ],
    [ "LimpiarTransp", "classImagen.html#aa3fd5e0c5d3ac1af55cbbd035bae29a1", null ],
    [ "num_cols", "classImagen.html#a91a9ab285292cd594c54c1119dd93484", null ],
    [ "num_filas", "classImagen.html#a4cb4faa04f5e2913965e43a6a65acfd1", null ],
    [ "operator()", "classImagen.html#a543676cda2b52696ad8b60ae05a6aaef", null ],
    [ "operator()", "classImagen.html#af812475a43d64b6105825b673bf4ebd5", null ],
    [ "operator=", "classImagen.html#a7c48a30723a8ef8aa29eb0deccc4af2f", null ],
    [ "PutImagen", "classImagen.html#ae5a805baddaa05b134f0dc2347726559", null ],
    [ "data", "classImagen.html#a18cfd5d6730f63e436a245920f09e879", null ],
    [ "nc", "classImagen.html#a0921ad9dff3caf6bb4d86eb7c1aeba60", null ],
    [ "nf", "classImagen.html#ae057b7b7de2b7d6371f9c89fdc3358fe", null ]
];