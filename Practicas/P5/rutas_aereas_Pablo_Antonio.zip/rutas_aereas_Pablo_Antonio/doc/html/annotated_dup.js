var annotated_dup =
[
    [ "AlmacenRutas", "classAlmacenRutas.html", "classAlmacenRutas" ],
    [ "Imagen", "classImagen.html", "classImagen" ],
    [ "Pais", "classPais.html", "classPais" ],
    [ "Paises", "classPaises.html", "classPaises" ],
    [ "Pixel", "structPixel.html", "structPixel" ],
    [ "Punto", "classPunto.html", "classPunto" ],
    [ "Ruta", "classRuta.html", "classRuta" ]
];