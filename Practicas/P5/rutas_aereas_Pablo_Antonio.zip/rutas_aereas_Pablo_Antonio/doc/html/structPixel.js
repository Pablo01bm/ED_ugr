var structPixel =
[
    [ "b", "structPixel.html#a760bdf29b15433d257f119239fcff4d4", null ],
    [ "g", "structPixel.html#a8407845aacf1663d9463475619911686", null ],
    [ "r", "structPixel.html#a038ad5b3349e7548d17c5d3bec511b94", null ],
    [ "transp", "structPixel.html#a711c15c873e7c61a643ea45a000060c8", null ]
];